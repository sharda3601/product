import './App.css';

import Modal from './Pages/Modal';
function App() {
  return (
    <div className="App">
    {/* <BrowserRouter>
     <Routes>
     <Route path="/" element={<Protected Cmp={ListProduct}/>}/>
      <Route path="/register" element={<Register/>}/>
      <Route path='/login' element={<Login/>}/>
      <Route path="/addproduct" element={<Protected Cmp={AddProduct}/>}></Route>
      <Route path="/update" element={<Protected Cmp={Update}/>}></Route>
     </Routes>
     </BrowserRouter> */}

     <Modal/>
    </div>
  );
}

export default App;
